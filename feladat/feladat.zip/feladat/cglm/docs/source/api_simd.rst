SIMD API
================================

SIMD api is special api for SIMD operations. **glmm_** prefix is used for SIMD operations in cglm. It is used in many places in cglm.
You can use it for your own SIMD operations too. In the future the api may be extended by time.

Supported SIMD architectures ( may vary by time )

* SSE / SSE2
* AVX
* NEON
* WASM 128
