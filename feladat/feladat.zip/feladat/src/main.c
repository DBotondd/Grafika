#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>
#include <math.h>

#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <cglm/cglm.h>

#include "camera.h"
#include "shader.h"
#include "model.h"
#include "fog.h"
#include "texture.h"
#include "stb_image.h"

// ablakméret
#define SCR_WIDTH   800
#define SCR_HEIGHT  600
#define GROUND_EXTENT 100.0f

// fizika & mozgás
const float BALL_RADIUS        = 0.5f;
const float GRAVITY            = 9.81f;
const float FRICTION           = 0.8f;
const float BOUND              = 10.0f;
const float CAM_SPEED          = 2.5f;
const float KICK_FORCE         = 10.0f;
const float GOAL_RESET_TIME    = 2.0f;
const float GOAL_TEXT_DURATION = 1.5f;
const float MISS_TEXT_DURATION = 1.5f;
const float WIN_TEXT_DURATION  = 2.0f;    // WIN/LOSE overlay időtartam

// füst részecskék
#define MAX_PARTICLES 200
typedef struct { vec3 pos, vel; float life; } Particle;
static Particle particles[MAX_PARTICLES];
static int      particleCount = 0;
unsigned smokeVAO, smokeVBO;

// kapuháló (NET)
enum { NET_R = 10, NET_C = 20 };
int    netCount;
unsigned netVAO, netVBO;

// kapus
unsigned keeperVAO, keeperVBO;
vec3     keeperPos;
float    keeperDir   = 1.0f;     // 1 = jobbra, -1 = balra
const float KEEPER_SPEED = 2.0f; // egység/másodperc

// célirányzó nyíl
float   aimYaw   = -90.0f;
float   aimPitch =   0.0f;
#define ARROW_LENGTH 5.0f
unsigned lineVAO, lineVBO;

// kamera & idő
Camera camera;
float  lastX      = SCR_WIDTH/2.0f, lastY = SCR_HEIGHT/2.0f;
bool   firstMouse = true;
float  deltaTime  = 0.0f, lastFrame = 0.0f;

// kapuháló elé állított vízszintes z-tengely (global)
const float boxFrontZ = -8.0f + (16.5f/16.5f)*5.0f + 2.0f;

// UI overlay-ekhez
unsigned helpVAO, helpVBO, helpTex;
unsigned goalTex, missTex, winTex, loseTex;
float    volume     = 1.0f;
bool     helpActive = false;

float overlayTimer = 0.0f;

// Számláló/WIN-LOSE
int playerScore = 0, keeperScore = 0;
#define SCORE_TO_WIN 5
bool gameOver = false;
bool showWin  = false;
bool showLose = false;
float winLoseTimer = 0.0f;

// segédfüggvények
void spawnSmoke(vec3 cp, int N){
    for(int i = 0; i < N && particleCount < MAX_PARTICLES; i++){
        Particle *p = &particles[particleCount++];
        glm_vec3_copy(cp, p->pos);
        p->vel[0] = ((rand()/(float)RAND_MAX)*2.0f - 1.0f)*0.5f;
        p->vel[1] = 1.0f + (rand()/(float)RAND_MAX)*0.5f;
        p->vel[2] = ((rand()/(float)RAND_MAX)*2.0f - 1.0f)*0.5f;
        p->life   = 1.0f;
    }
}
void updateSmoke(float dt){
    int dst = 0;
    for(int i = 0; i < particleCount; i++){
        Particle *p = &particles[i];
        p->life -= dt;
        if(p->life > 0.0f){
            vec3 d;
            glm_vec3_scale(p->vel, dt, d);
            glm_vec3_add(p->pos, d, p->pos);
            particles[dst++] = *p;
        }
    }
    particleCount = dst;
}

void UpdateWindowTitle(GLFWwindow* window, int playerScore, int keeperScore) {
    char title[128];
    snprintf(title, sizeof(title), "3D Soccer – %d : %d", playerScore, keeperScore);
    glfwSetWindowTitle(window, title);
}

// callback-ok
void processInput(GLFWwindow *w);
void framebuffer_size_callback(GLFWwindow* window, int w, int h);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);

int main(void){
    srand((unsigned)time(NULL));

    if(!glfwInit()) return EXIT_FAILURE;
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR,3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR,3);
    glfwWindowHint(GLFW_OPENGL_PROFILE,GLFW_OPENGL_CORE_PROFILE);
  #ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT,GL_TRUE);
  #endif

    GLFWwindow *window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "3D Soccer", NULL, NULL);
    if(!window){ glfwTerminate(); return EXIT_FAILURE; }
    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    glfwSetCursorPosCallback(window, mouse_callback);
    glfwSetScrollCallback(window, scroll_callback);
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    glewExperimental = GL_TRUE;
    if(glewInit() != GLEW_OK) return EXIT_FAILURE;

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_PROGRAM_POINT_SIZE);

    glClearColor(0.4f, 0.6f, 0.9f, 1.0f);

    UpdateWindowTitle(window, 0, 0);

    // Shaderek betöltése és beállítása
    Shader sceneSh  = Shader_New("shaders/vertex.glsl",       "shaders/fragment.glsl");
    Shader groundSh = Shader_New("shaders/ground_vert.glsl",  "shaders/ground_frag.glsl");
    Shader uiSh     = Shader_New("shaders/ui_vert.glsl",      "shaders/ui_frag.glsl");
    Shader smokeSh  = Shader_New("shaders/smoke_vertex.glsl", "shaders/smoke_fragment.glsl");
    Shader lineSh   = Shader_New("shaders/line_vert.glsl",    "shaders/line_frag.glsl");
    Shader spriteSh = Shader_New("shaders/sprite_vert.glsl",  "shaders/sprite_frag.glsl");

    Shader_Use(&sceneSh);  Shader_SetInt(&sceneSh, "texture_diffuse1", 0);
    Shader_Use(&uiSh);     Shader_SetInt(&uiSh,    "uiTexture",       0);

    // ground VAO/VBO
    float groundVerts[] = {
        -GROUND_EXTENT, 0, -GROUND_EXTENT,
        -GROUND_EXTENT, 0,  GROUND_EXTENT,
         GROUND_EXTENT, 0,  GROUND_EXTENT,
         GROUND_EXTENT, 0, -GROUND_EXTENT
    };
    unsigned groundVAO, groundVBO;
    glGenVertexArrays(1, &groundVAO);
    glGenBuffers(1, &groundVBO);
    glBindVertexArray(groundVAO);
      glBindBuffer(GL_ARRAY_BUFFER, groundVBO);
      glBufferData(GL_ARRAY_BUFFER, sizeof groundVerts, groundVerts, GL_STATIC_DRAW);
      glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);
      glEnableVertexAttribArray(0);
    glBindVertexArray(0);

    // UI quad VAO/VBO
    float uiVerts[] = {
      -1,  1,  0, 1,
       1,  1,  1, 1,
       1, -1,  1, 0,
      -1, -1,  0, 0
    };
    glGenVertexArrays(1, &helpVAO);
    glGenBuffers(1, &helpVBO);
    glBindVertexArray(helpVAO);
      glBindBuffer(GL_ARRAY_BUFFER, helpVBO);
      glBufferData(GL_ARRAY_BUFFER, sizeof uiVerts, uiVerts, GL_STATIC_DRAW);
      glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)0);
      glEnableVertexAttribArray(0);
      glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)(2 * sizeof(float)));
      glEnableVertexAttribArray(1);
    glBindVertexArray(0);

    // Textúrák betöltése
    stbi_set_flip_vertically_on_load(true);
    helpTex   = Texture_FromFile("assets/help.png");
    goalTex   = Texture_FromFile("assets/goal.png");
    missTex   = Texture_FromFile("assets/miss.png");
    winTex    = Texture_FromFile("assets/win.png");
    loseTex   = Texture_FromFile("assets/lose.png");
    unsigned keeperTex   = Texture_FromFile("assets/keeper.png");
    unsigned stadiumTex  = Texture_FromFile("assets/stadium.png");
    unsigned ballTex     = Texture_FromFile("assets/ball_diffuse.png");

    // Keeper VAO/VBO
    float keeperVerts[] = {
        -0.5f, 0.0f,  0.0f, 0.0f,
         0.5f, 0.0f,  1.0f, 0.0f,
         0.5f, 1.2f,  1.0f, 1.0f,
        -0.5f, 1.2f,  0.0f, 1.0f
    };
    glGenVertexArrays(1, &keeperVAO);
    glGenBuffers(1, &keeperVBO);
    glBindVertexArray(keeperVAO);
      glBindBuffer(GL_ARRAY_BUFFER, keeperVBO);
      glBufferData(GL_ARRAY_BUFFER, sizeof keeperVerts, keeperVerts, GL_STATIC_DRAW);
      glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)0);
      glEnableVertexAttribArray(0);
      glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)(2 * sizeof(float)));
      glEnableVertexAttribArray(1);
    glBindVertexArray(0);

    // Smoke VAO/VBO
    glGenVertexArrays(1, &smokeVAO);
    glGenBuffers(1, &smokeVBO);
    glBindVertexArray(smokeVAO);
      glBindBuffer(GL_ARRAY_BUFFER, smokeVBO);
      glBufferData(GL_ARRAY_BUFFER, MAX_PARTICLES * 4 * sizeof(float), NULL, GL_STREAM_DRAW);
      glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)0);
      glEnableVertexAttribArray(0);
    glBindVertexArray(0);

    // Kapuháló (NET) VAO/VBO
    netCount = (NET_R + 1 + NET_C + 1) * 2;
    float *net = malloc(netCount * 3 * sizeof(float));
    int idx = 0;
    for(int i = 0; i <= NET_R; i++){
      float y = i * (2.0f / NET_R);
      net[idx++] = -3; net[idx++] = y; net[idx++] = -8;
      net[idx++] =  3; net[idx++] = y; net[idx++] = -8;
    }
    for(int j = 0; j <= NET_C; j++){
      float x = -3 + j * (6.0f / NET_C);
      net[idx++] = x; net[idx++] = 0; net[idx++] = -8;
      net[idx++] = x; net[idx++] = 2; net[idx++] = -8;
    }
    glGenVertexArrays(1, &netVAO);
    glGenBuffers(1, &netVBO);
    glBindVertexArray(netVAO);
      glBindBuffer(GL_ARRAY_BUFFER, netVBO);
      glBufferData(GL_ARRAY_BUFFER, netCount * 3 * sizeof(float), net, GL_STATIC_DRAW);
      glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);
      glEnableVertexAttribArray(0);
    glBindVertexArray(0);
    free(net);

    // Célvonal VAO/VBO
    unsigned goalLineVAO, goalLineVBO;
    float goalLineVerts[] = {
        -BOUND, 0.01f, -8.0f,
         BOUND, 0.01f, -8.0f
    };
    glGenVertexArrays(1, &goalLineVAO);
    glGenBuffers(1, &goalLineVBO);
    glBindVertexArray(goalLineVAO);
      glBindBuffer(GL_ARRAY_BUFFER, goalLineVBO);
      glBufferData(GL_ARRAY_BUFFER, sizeof goalLineVerts, goalLineVerts, GL_STATIC_DRAW);
      glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);
      glEnableVertexAttribArray(0);
    glBindVertexArray(0);

    // Spot VAO/VBO (local SPOT_Z)
    const float SPOT_Z = -8.0f + (11.0f/16.5f)*5.0f + 2.0f;
    unsigned spotVAO, spotVBO;
    float spotVert[] = {
        0.0f, 0.01f, SPOT_Z
    };
    glGenVertexArrays(1, &spotVAO);
    glGenBuffers(1, &spotVBO);
    glBindVertexArray(spotVAO);
      glBindBuffer(GL_ARRAY_BUFFER, spotVBO);
      glBufferData(GL_ARRAY_BUFFER, sizeof spotVert, spotVert, GL_STATIC_DRAW);
      glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);
      glEnableVertexAttribArray(0);
    glBindVertexArray(0);

    // Doboz VAO/VBO
    unsigned boxVAO, boxVBO;
    float boxVerts[] = {
      -3.0f, 0.01f, -8.0f,   3.0f, 0.01f, -8.0f,
       3.0f, 0.01f,  boxFrontZ,  -3.0f, 0.01f,  boxFrontZ
    };
    glGenVertexArrays(1, &boxVAO);
    glGenBuffers(1, &boxVBO);
    glBindVertexArray(boxVAO);
      glBindBuffer(GL_ARRAY_BUFFER, boxVBO);
      glBufferData(GL_ARRAY_BUFFER, sizeof boxVerts, boxVerts, GL_STATIC_DRAW);
      glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);
      glEnableVertexAttribArray(0);
    glBindVertexArray(0);

    // Ív VAO/VBO
    #define ARC_SEGMENTS 64
    unsigned arcVAO, arcVBO;
    float arcVerts[ARC_SEGMENTS * 3];
    float arcR    = (9.15f/16.5f) * 5.0f;
    float dz      = boxFrontZ - SPOT_Z;
    float phi0    = acosf(dz / arcR);
    for(int i = 0; i < ARC_SEGMENTS; i++){
        float t = -phi0 + 2 * phi0 * (i / (float)(ARC_SEGMENTS - 1));
        arcVerts[3*i + 0] =  sinf(t) * arcR;
        arcVerts[3*i + 1] =  0.01f;
        arcVerts[3*i + 2] =  SPOT_Z + cosf(t) * arcR;
    }
    glGenVertexArrays(1, &arcVAO);
    glGenBuffers(1, &arcVBO);
    glBindVertexArray(arcVAO);
      glBindBuffer(GL_ARRAY_BUFFER, arcVBO);
      glBufferData(GL_ARRAY_BUFFER, sizeof arcVerts, arcVerts, GL_STATIC_DRAW);
      glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, (void*)0);
      glEnableVertexAttribArray(0);
    glBindVertexArray(0);

    // Kocka VAO/VBO (kapufa alsó és felső tartóoszlopokhoz, vízszintes rúdhoz)
    static const float cubeMesh[] = {
       -0.5f,-0.5f,-0.5f,  0.5f, 0.5f,-0.5f,  0.5f,-0.5f,-0.5f,
        0.5f, 0.5f,-0.5f, -0.5f,-0.5f,-0.5f, -0.5f, 0.5f,-0.5f,
       -0.5f,-0.5f, 0.5f,  0.5f,-0.5f, 0.5f,  0.5f, 0.5f, 0.5f,
        0.5f, 0.5f, 0.5f, -0.5f, 0.5f, 0.5f, -0.5f,-0.5f, 0.5f,
       -0.5f, 0.5f, 0.5f, -0.5f, 0.5f,-0.5f, -0.5f,-0.5f,-0.5f,
       -0.5f,-0.5f,-0.5f, -0.5f,-0.5f, 0.5f, -0.5f, 0.5f, 0.5f,
        0.5f, 0.5f, 0.5f,  0.5f,-0.5f,-0.5f,  0.5f, 0.5f,-0.5f,
        0.5f,-0.5f,-0.5f,  0.5f, 0.5f, 0.5f,  0.5f,-0.5f, 0.5f,
       -0.5f,-0.5f,-0.5f,  0.5f,-0.5f,-0.5f,  0.5f,-0.5f, 0.5f,
        0.5f,-0.5f, 0.5f, -0.5f,-0.5f, 0.5f, -0.5f,-0.5f,-0.5f,
       -0.5f, 0.5f,-0.5f, -0.5f, 0.5f, 0.5f,  0.5f, 0.5f, 0.5f,
        0.5f, 0.5f, 0.5f,  0.5f, 0.5f,-0.5f, -0.5f, 0.5f,-0.5f
    };
    unsigned cubeVAO, cubeVBO;
    glGenVertexArrays(1, &cubeVAO);
    glGenBuffers(1, &cubeVBO);
    glBindVertexArray(cubeVAO);
      glBindBuffer(GL_ARRAY_BUFFER, cubeVBO);
      glBufferData(GL_ARRAY_BUFFER, sizeof cubeMesh, cubeMesh, GL_STATIC_DRAW);
      glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
      glEnableVertexAttribArray(0);
    glBindVertexArray(0);

    // Nyíl VAO/VBO
    glGenVertexArrays(1, &lineVAO);
    glGenBuffers(1, &lineVBO);
    glBindVertexArray(lineVAO);
      glBindBuffer(GL_ARRAY_BUFFER, lineVBO);
      glBufferData(GL_ARRAY_BUFFER, 2 * 3 * sizeof(float), NULL, GL_DYNAMIC_DRAW);
      glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);
      glEnableVertexAttribArray(0);
    glBindVertexArray(0);

    // Labda modell betöltése
    Model ballModel;
    if(!Model_Load(&ballModel, "assets/ball_uv.obj")) return EXIT_FAILURE;

    // Kamera és köd inicializálása
    Camera_Init(&camera, (vec3){0,1,5}, (vec3){0,1,0}, CAMERA_YAW, CAMERA_PITCH);
    Fog fog; Fog_Init(&fog, 0.045f, 1.5f);

    // Labda állapot
    vec3 ballPos = {0, BALL_RADIUS, SPOT_Z}, ballVel = {0, 0, 0};
    bool scored = false;
    bool missed = false;
    float goalTimer = 0.0f, missTimer = 0.0f;

    bool arrowVisible = true;

    glm_vec3_copy((vec3){0, 0, -7.5f}, keeperPos);

    while(!glfwWindowShouldClose(window)){
        float now = (float)glfwGetTime();
        deltaTime = now - lastFrame; lastFrame = now;

        processInput(window);

        // Kamera korlátok
        camera.Position[0] = fmaxf(-BOUND, fminf(BOUND, camera.Position[0]));
        camera.Position[2] = fmaxf(-BOUND, fminf(BOUND, camera.Position[2]));
        camera.Position[1] = fmaxf(1.0f, camera.Position[1]);

        if(gameOver) {
            winLoseTimer -= deltaTime;
            if(winLoseTimer <= 0.0f) {
                playerScore = 0; keeperScore = 0;
                scored = missed = gameOver = showWin = showLose = false;
                winLoseTimer = 0.0f;
                glm_vec3_copy((vec3){0, BALL_RADIUS, SPOT_Z}, ballPos);
                glm_vec3_zero(ballVel);
                camera.Position[0] = 0; camera.Position[1] = 1; camera.Position[2] = 5;
                camera.Yaw = -90; camera.Pitch = 0;
                Camera_UpdateVectors(&camera);

                arrowVisible = true;

                UpdateWindowTitle(window, playerScore, keeperScore);
            }
        } else {
            // Kapus mozgatása
            keeperPos[0] += keeperDir * KEEPER_SPEED * deltaTime;
            if(keeperPos[0] > 2.0f){ keeperPos[0] = 2.0f; keeperDir = -1; }
            if(keeperPos[0] < -2.0f){ keeperPos[0] = -2.0f; keeperDir = +1; }

            // Rugás
            if(!scored && missTimer <= 0.0f && goalTimer <= 0.0f && glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS){
                arrowVisible = false;
                float yR = glm_rad(aimYaw), pR = glm_rad(aimPitch);
                vec3 aimDir = {
                  cosf(pR)*cosf(yR),
                  sinf(pR),
                  cosf(pR)*sinf(yR)
                };
                glm_vec3_normalize(aimDir);
                glm_vec3_scale(aimDir, KICK_FORCE, ballVel);
            }

            // Gravitáció és pozíció frissítés
            ballVel[1] -= GRAVITY * deltaTime;
            vec3 dv; glm_vec3_scale(ballVel, deltaTime, dv);
            glm_vec3_add(ballPos, dv, ballPos);
            if(ballPos[1] < BALL_RADIUS){
                ballPos[1] = BALL_RADIUS;
                ballVel[1] *= -0.5f;
                ballVel[0] *= FRICTION; ballVel[2] *= FRICTION;
            }
            ballPos[0] = fmaxf(-BOUND, fminf(BOUND, ballPos[0]));
            ballPos[2] = fmaxf(-BOUND, fminf(BOUND, ballPos[2]));

            updateSmoke(deltaTime);

            // Gól vagy hiba detektálása
            if(ballPos[2] - BALL_RADIUS < keeperPos[2] + 0.2f &&
               fabsf(ballPos[0] - keeperPos[0]) < 0.5f &&
               ballPos[1] < 2.0f &&
               missTimer <= 0.0f && goalTimer <= 0.0f && !scored)
            {
                missTimer = MISS_TEXT_DURATION;
                missed = true;
                keeperScore++;
                printf("MISS!!! 😕 Kapus: %d Játékos: %d\n", keeperScore, playerScore);
                UpdateWindowTitle(window, playerScore, keeperScore);
                ballVel[0] = ballVel[1] = ballVel[2] = 0.0f;
            }

            else if(ballPos[2] - BALL_RADIUS < -8.0f &&
                    (ballPos[0] < -3.0f || ballPos[0] > 3.0f) &&
                    missTimer <= 0.0f && goalTimer <= 0.0f && !scored)
            {
                missed = true;
                missTimer = MISS_TEXT_DURATION;
                keeperScore++;
                printf("MISS!!! 😕 Kapus: %d Játékos: %d\n", keeperScore, playerScore);
                UpdateWindowTitle(window, playerScore, keeperScore);
                ballVel[0] = ballVel[1] = ballVel[2] = 0.0f;
            }

            else if (!scored && !missed
                     && ballPos[2] - BALL_RADIUS < -8.0f
                     && (ballPos[0] <= -3.0f || ballPos[0] >= 3.0f || ballPos[1] >= 2.0f))
            {
                missed    = true;
                missTimer = MISS_TEXT_DURATION;
                keeperScore++;
                printf("MISS!!! 😢 Kapus: %d Játékos: %d\n", keeperScore, playerScore);
                UpdateWindowTitle(window, playerScore, keeperScore);
            }

            if (!scored && !missed
                && ballPos[2] - BALL_RADIUS < -8.0f
                && ballPos[0] > -3.0f && ballPos[0] < 3.0f
                && ballPos[1] < 2.0f)
            {
                scored   = true;
                goalTimer = GOAL_TEXT_DURATION;
                spawnSmoke(ballPos, 200);
                playerScore++;
                printf("GOAL!!! 🥳 Játékos: %d Kapus: %d\n", playerScore, keeperScore);
                UpdateWindowTitle(window, playerScore, keeperScore);
            }

            if(goalTimer > 0.0f) goalTimer -= deltaTime;
            if(missTimer > 0.0f) missTimer -= deltaTime;

            if((goalTimer <= 0.0f && scored) ||
               (missTimer <= 0.0f && missed))
            {
                if(playerScore >= SCORE_TO_WIN) {
                    showWin = true;
                    gameOver = true;
                    winLoseTimer = WIN_TEXT_DURATION;
                    printf("=== JÁTÉKOS NYERT! ===\n");
                } else if(keeperScore >= SCORE_TO_WIN) {
                    showLose = true;
                    gameOver = true;
                    winLoseTimer = WIN_TEXT_DURATION;
                    printf("=== KAPUS NYERT! ===\n");
                }
                if(!gameOver){
                    glm_vec3_copy((vec3){0, BALL_RADIUS, SPOT_Z}, ballPos);
                    glm_vec3_zero(ballVel);
                    camera.Position[0] = 0; camera.Position[1] = 1; camera.Position[2] = 5;
                    camera.Yaw = -90; camera.Pitch = 0;
                    Camera_UpdateVectors(&camera);

                    scored = false;
                    missed = false;
                    arrowVisible = true;
                }
            }
        }

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // Háttér textúra kirajzolása UI-val
        glDisable(GL_DEPTH_TEST);
        Shader_Use(&uiSh);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, stadiumTex);
        glBindVertexArray(helpVAO);
        glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
        glEnable(GL_DEPTH_TEST);

        // Kamera nézet és vetítési mátrix
        mat4 proj, view;
        glm_perspective(glm_rad(camera.Zoom),
                        (float)SCR_WIDTH / SCR_HEIGHT,
                        0.1f, 100.0f, proj);
        Camera_GetViewMatrix(&camera, view);

        // Talaj kirajzolása
        {
            mat4 M; glm_mat4_identity(M);
            Shader_Use(&groundSh);
            Shader_SetMat4(&groundSh, "view", view);
            Shader_SetMat4(&groundSh, "projection", proj);
            Shader_SetMat4(&groundSh, "model", M);
            glBindVertexArray(groundVAO);
            glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
        }

        // Kapu keret és vonalak kirajzolása
        {
            Shader_Use(&lineSh);
            Shader_SetVec3(&lineSh, "objectColor", (vec3){1,1,1});
            Shader_SetMat4(&lineSh, "view", view);
            Shader_SetMat4(&lineSh, "projection", proj);

            // Gólvonal
            glBindVertexArray(goalLineVAO);
            glDrawArrays(GL_LINES, 0, 2);

            // Doboz kontúr
            glBindVertexArray(boxVAO);
            glDrawArrays(GL_LINE_LOOP, 0, 4);

            // Pont (spot) a büntetőpontnál
            glPointSize(6.0f);
            glBindVertexArray(spotVAO);
            glDrawArrays(GL_POINTS, 0, 1);
            glPointSize(1.0f);

            // Ív kirajzolása
            glBindVertexArray(arcVAO);
            glDrawArrays(GL_LINE_STRIP, 0, ARC_SEGMENTS);

            glBindVertexArray(0);
        }

        // Labda kirajzolása
        {
            mat4 M; glm_mat4_identity(M);
            glm_translate(M, ballPos);
            glm_scale(M, (vec3){BALL_RADIUS, BALL_RADIUS, BALL_RADIUS});
            Shader_Use(&sceneSh);
            Shader_SetMat4(&sceneSh, "model", M);
            Shader_SetMat4(&sceneSh, "view", view);
            Shader_SetMat4(&sceneSh, "projection", proj);
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, ballTex);
            Fog_Apply(&fog, &sceneSh);
            Model_Draw(&ballModel);
        }

        // Füst részecskék kirajzolása
        {
            float *buf = malloc(particleCount * 4 * sizeof(float));
            for(int i = 0; i < particleCount; i++){
                buf[4*i + 0] = particles[i].pos[0];
                buf[4*i + 1] = particles[i].pos[1];
                buf[4*i + 2] = particles[i].pos[2];
                buf[4*i + 3] = particles[i].life;
            }
            glBindBuffer(GL_ARRAY_BUFFER, smokeVBO);
            glBufferSubData(GL_ARRAY_BUFFER, 0, particleCount * 4 * sizeof(float), buf);
            free(buf);
            Shader_Use(&smokeSh);
            Shader_SetMat4(&smokeSh, "view", view);
            Shader_SetMat4(&smokeSh, "projection", proj);
            glBindVertexArray(smokeVAO);
            glDrawArrays(GL_POINTS, 0, particleCount);
        }

        // Kapufa tartóoszlopok és vízszintes rúd
        {
            Shader_Use(&sceneSh);
            mat4 M;

            // Bal oszlop
            glm_mat4_identity(M);
            glm_translate(M, (vec3){-3, 1, -8});
            glm_scale(M, (vec3){0.2f, 2.5f, 0.2f});
            Shader_SetMat4(&sceneSh, "model", M);
            glBindVertexArray(cubeVAO);
            glDrawArrays(GL_TRIANGLES, 0, 36);

            // Jobb oszlop
            glm_mat4_identity(M);
            glm_translate(M, (vec3){3, 1, -8});
            glm_scale(M, (vec3){0.2f, 2.5f, 0.2f});
            Shader_SetMat4(&sceneSh, "model", M);
            glDrawArrays(GL_TRIANGLES, 0, 36);

            // Vízhenglyes rúd
            glm_mat4_identity(M);
            glm_translate(M, (vec3){0, 2.25f, -8});
            glm_scale(M, (vec3){6.0f, 0.2f, 0.2f});
            Shader_SetMat4(&sceneSh, "model", M);
            glDrawArrays(GL_TRIANGLES, 0, 36);
        }

        // Kapuháló szálai
        {
            Shader_Use(&lineSh);
            Shader_SetVec3(&lineSh, "objectColor", (vec3){1,1,1});
            Shader_SetMat4(&lineSh, "view", view);
            Shader_SetMat4(&lineSh, "projection", proj);
            glBindVertexArray(netVAO);
            glDrawArrays(GL_LINES, 0, netCount);
        }

        // Kapus kirajzolása (sprite)
        {
            mat4 M;
            glm_mat4_identity(M);
            glm_translate(M, keeperPos);
            glm_scale(M, (vec3){1.0f, 1.8f, 1.0f});
            Shader_Use(&spriteSh);
            Shader_SetMat4(&spriteSh, "model",      M);
            Shader_SetMat4(&spriteSh, "view",       view);
            Shader_SetMat4(&spriteSh, "projection", proj);
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, keeperTex);
            glBindVertexArray(keeperVAO);
            glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
        }

        // Célirányzó nyíl kirajzolása
        if (arrowVisible) {
            vec3 start, end;
            glm_vec3_copy(ballPos, start);
            float yR = glm_rad(aimYaw), pR = glm_rad(aimPitch);
            end[0] = start[0] + cosf(pR)*cosf(yR) * ARROW_LENGTH;
            end[1] = start[1] + sinf(pR) * ARROW_LENGTH;
            end[2] = start[2] + cosf(pR)*sinf(yR) * ARROW_LENGTH;
            float verts[6] = {
                start[0], start[1], start[2],
                end[0],   end[1],   end[2]
            };
            glBindBuffer(GL_ARRAY_BUFFER, lineVBO);
            glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof verts, verts);
            Shader_Use(&lineSh);
            Shader_SetVec3(&lineSh, "objectColor", (vec3){1,0,0});
            Shader_SetMat4(&lineSh, "view", view);
            Shader_SetMat4(&lineSh, "projection", proj);
            glBindVertexArray(lineVAO);
            glDrawArrays(GL_LINES, 0, 2);
        }

        // Segítség overlay
        if(helpActive){
            glDisable(GL_DEPTH_TEST);
            Shader_Use(&uiSh);
            glBindTexture(GL_TEXTURE_2D, helpTex);
            glBindVertexArray(helpVAO);
            glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
            glEnable(GL_DEPTH_TEST);
        }

        // Gól/miss overlay
        if(goalTimer > 0.0f || missTimer > 0.0f){
            glDisable(GL_DEPTH_TEST);
            Shader_Use(&uiSh);
            glBindTexture(GL_TEXTURE_2D, goalTimer > 0.0f ? goalTex : missTex);
            glBindVertexArray(helpVAO);
            glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
            glEnable(GL_DEPTH_TEST);
        }

        // Win/Lose overlay
        if(showWin && gameOver && winLoseTimer > 0.0f){
            glDisable(GL_DEPTH_TEST);
            Shader_Use(&uiSh);
            glBindTexture(GL_TEXTURE_2D, winTex);
            glBindVertexArray(helpVAO);
            glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
            glEnable(GL_DEPTH_TEST);
        }
        if(showLose && gameOver && winLoseTimer > 0.0f){
            glDisable(GL_DEPTH_TEST);
            Shader_Use(&uiSh);
            glBindTexture(GL_TEXTURE_2D, loseTex);
            glBindVertexArray(helpVAO);
            glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
            glEnable(GL_DEPTH_TEST);
        }

        // Konzolos HUD
        printf("\rJátékos: %d    Kapus: %d         ", playerScore, keeperScore);
        fflush(stdout);

        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    // Felszabadítás
    Model_Cleanup(&ballModel);
    Shader_Delete(&sceneSh);
    Shader_Delete(&groundSh);
    Shader_Delete(&uiSh);
    Shader_Delete(&smokeSh);
    Shader_Delete(&lineSh);
    Shader_Delete(&spriteSh);
    glDeleteVertexArrays(1, &groundVAO);  glDeleteBuffers(1, &groundVBO);
    glDeleteVertexArrays(1, &netVAO);     glDeleteBuffers(1, &netVBO);
    glDeleteVertexArrays(1, &cubeVAO);    glDeleteBuffers(1, &cubeVBO);
    glDeleteVertexArrays(1, &smokeVAO);   glDeleteBuffers(1, &smokeVBO);
    glDeleteVertexArrays(1, &lineVAO);    glDeleteBuffers(1, &lineVBO);
    glDeleteVertexArrays(1, &helpVAO);    glDeleteBuffers(1, &helpVBO);
    glDeleteVertexArrays(1, &keeperVAO);  glDeleteBuffers(1, &keeperVBO);
    glDeleteVertexArrays(1, &goalLineVAO); glDeleteBuffers(1, &goalLineVBO);
    glDeleteVertexArrays(1, &spotVAO);    glDeleteBuffers(1, &spotVBO);
    glDeleteVertexArrays(1, &boxVAO);     glDeleteBuffers(1, &boxVBO);
    glDeleteVertexArrays(1, &arcVAO);     glDeleteBuffers(1, &arcVBO);
    glDeleteVertexArrays(1, &cubeVAO);    glDeleteBuffers(1, &cubeVBO);

    glfwTerminate();
    return EXIT_SUCCESS;
}

void processInput(GLFWwindow* w){
    if(glfwGetKey(w, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(w, true);

    Camera_ProcessKeyboard(&camera, CAMERA_MV_FORWARD,
        deltaTime * ((glfwGetKey(w, GLFW_KEY_W) == GLFW_PRESS) ? CAM_SPEED : 1.0f));
    Camera_ProcessKeyboard(&camera, CAMERA_MV_BACKWARD,
        deltaTime * ((glfwGetKey(w, GLFW_KEY_S) == GLFW_PRESS) ? CAM_SPEED : 1.0f));
    Camera_ProcessKeyboard(&camera, CAMERA_MV_LEFT,
        deltaTime * ((glfwGetKey(w, GLFW_KEY_A) == GLFW_PRESS) ? CAM_SPEED : 1.0f));
    Camera_ProcessKeyboard(&camera, CAMERA_MV_RIGHT,
        deltaTime * ((glfwGetKey(w, GLFW_KEY_D) == GLFW_PRESS) ? CAM_SPEED : 1.0f));

    float spd = 60.0f * deltaTime;
    if(glfwGetKey(w, GLFW_KEY_LEFT)  == GLFW_PRESS) aimYaw   -= spd;
    if(glfwGetKey(w, GLFW_KEY_RIGHT) == GLFW_PRESS) aimYaw   += spd;
    if(glfwGetKey(w, GLFW_KEY_UP)    == GLFW_PRESS) aimPitch  = fminf(89.0f,  aimPitch + spd);
    if(glfwGetKey(w, GLFW_KEY_DOWN)  == GLFW_PRESS) aimPitch  = fmaxf(-89.0f, aimPitch - spd);

    if(glfwGetKey(w, GLFW_KEY_KP_ADD)   == GLFW_PRESS ||
       glfwGetKey(w, GLFW_KEY_EQUAL)    == GLFW_PRESS)
    {
        volume = fminf(1.0f, volume + 0.1f);
        printf("Volume: %d%%\n", (int)(volume * 100));
    }
    if(glfwGetKey(w, GLFW_KEY_KP_SUBTRACT) == GLFW_PRESS ||
       glfwGetKey(w, GLFW_KEY_MINUS)       == GLFW_PRESS)
    {
        volume = fmaxf(0.0f, volume - 0.1f);
        printf("Volume: %d%%\n", (int)(volume * 100));
    }

    static bool f1last = false;
    bool f1now = (glfwGetKey(w, GLFW_KEY_F1) == GLFW_PRESS);
    if(f1now && !f1last) helpActive = !helpActive;
    f1last = f1now;

    float rotSpeed = 60.0f * deltaTime;
    if(glfwGetKey(w, GLFW_KEY_J) == GLFW_PRESS) {
        Camera_ProcessMouseMovement(&camera, -rotSpeed, 0.0f, true);
    }
    if(glfwGetKey(w, GLFW_KEY_K) == GLFW_PRESS) {
        Camera_ProcessMouseMovement(&camera,  rotSpeed, 0.0f, true);
    }
}

void framebuffer_size_callback(GLFWwindow* window, int w, int h){
    (void)window;
    glViewport(0, 0, w, h);
}

void mouse_callback(GLFWwindow* window, double xpos, double ypos){
    (void)window;
    if(firstMouse){
        lastX = xpos;
        lastY = ypos;
        firstMouse = false;
    }
    float xoff = (float)xpos - lastX;
    float yoff = lastY - (float)ypos;
    lastX = xpos;
    lastY = ypos;
    Camera_ProcessMouseMovement(&camera, xoff, yoff, true);
}

void scroll_callback(GLFWwindow* window, double xoffset, double yoffset){
    (void)window;
    (void)xoffset;
    Camera_ProcessMouseScroll(&camera, (float)yoffset);
}
