// src/main.c

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>
#include <math.h>

#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <cglm/cglm.h>

#include "camera.h"
#include "shader.h"
#include "model.h"
#include "fog.h"
#include "texture.h"

// ---------- Simple smoke particle system ----------
#define MAX_PARTICLES 200
typedef struct {
    vec3 pos, vel;
    float life;
} Particle;
static Particle particles[MAX_PARTICLES];
static int      particleCount = 0;

void spawnSmoke(vec3 cp, int N) {
    for (int i = 0; i < N && particleCount < MAX_PARTICLES; i++) {
        Particle *p = &particles[particleCount++];
        glm_vec3_copy(cp, p->pos);
        p->vel[0] = ((rand() / (float)RAND_MAX) * 2.0f - 1.0f) * 0.5f;
        p->vel[1] = 1.0f + (rand() / (float)RAND_MAX) * 0.5f;
        p->vel[2] = ((rand() / (float)RAND_MAX) * 2.0f - 1.0f) * 0.5f;
        p->life   = 1.0f;
    }
}

void updateSmoke(float dt) {
    int dst = 0;
    for (int i = 0; i < particleCount; i++) {
        Particle *p = &particles[i];
        p->life -= dt;
        if (p->life > 0.0f) {
            vec3 d; glm_vec3_scale(p->vel, dt, d);
            glm_vec3_add(p->pos, d, p->pos);
            particles[dst++] = *p;
        }
    }
    particleCount = dst;
}
// ---------------------------------------------------

// Cube mesh for goal posts & crossbar (36 verts)
static const float cubeMesh[] = {
   -0.5,-0.5,-0.5,  0.5, 0.5,-0.5,  0.5,-0.5,-0.5,
    0.5, 0.5,-0.5, -0.5,-0.5,-0.5, -0.5, 0.5,-0.5,
   -0.5,-0.5, 0.5,  0.5,-0.5, 0.5,  0.5, 0.5, 0.5,
    0.5, 0.5, 0.5, -0.5, 0.5, 0.5, -0.5,-0.5, 0.5,
   -0.5, 0.5, 0.5, -0.5, 0.5,-0.5, -0.5,-0.5,-0.5,
   -0.5,-0.5,-0.5, -0.5,-0.5, 0.5, -0.5, 0.5, 0.5,
    0.5, 0.5, 0.5,  0.5,-0.5,-0.5,  0.5, 0.5,-0.5,
    0.5,-0.5,-0.5,  0.5, 0.5, 0.5,  0.5,-0.5, 0.5,
   -0.5,-0.5,-0.5,  0.5,-0.5,-0.5,  0.5,-0.5, 0.5,
    0.5,-0.5, 0.5, -0.5,-0.5, 0.5, -0.5,-0.5,-0.5,
   -0.5, 0.5,-0.5, -0.5, 0.5, 0.5,  0.5, 0.5, 0.5,
    0.5, 0.5, 0.5,  0.5, 0.5,-0.5, -0.5, 0.5,-0.5
};

const unsigned int SCR_WIDTH  = 800;
const unsigned int SCR_HEIGHT = 600;

// Movement & physics constants
const float CAM_SPEED   = 2.5f;
const float KICK_FORCE  = 10.0f;
const float GRAVITY     = 9.81f;
const float FRICTION    = 0.8f;
const float BOUND       = 10.0f;
const float BALL_RADIUS = 0.5f;

// Globals for camera & timing
Camera camera;
float  lastX      = SCR_WIDTH/2.0f;
float  lastY      = SCR_HEIGHT/2.0f;
bool   firstMouse = true;
float  deltaTime  = 0.0f;
float  lastFrame  = 0.0f;

// Callback prototypes
void processInput(GLFWwindow* window);
void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);

int main(void) {
    srand((unsigned)time(NULL));

    // --- GLFW init ---
    if (!glfwInit()) return EXIT_FAILURE;
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR,3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR,3);
    glfwWindowHint(GLFW_OPENGL_PROFILE,GLFW_OPENGL_CORE_PROFILE);
  #ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT,GL_TRUE);
  #endif

    GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT,
        "3D Soccer Field", NULL, NULL);
    if (!window) { glfwTerminate(); return EXIT_FAILURE; }
    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
    glfwSetCursorPosCallback(window, mouse_callback);
    glfwSetScrollCallback(window, scroll_callback);
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // --- GLEW init ---
    glewExperimental = GL_TRUE;
    if (glewInit() != GLEW_OK) return EXIT_FAILURE;

    // OpenGL state
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_PROGRAM_POINT_SIZE);

    // Sky color
    glClearColor(0.529f, 0.808f, 0.922f, 1.0f);

    // --- Load shaders ---
    Shader sceneShader  = Shader_New("shaders/vertex.glsl",      "shaders/fragment.glsl");
    Shader lineShader   = Shader_New("shaders/line_vert.glsl",   "shaders/line_frag.glsl");
    Shader smokeShader  = Shader_New("shaders/smoke_vertex.glsl","shaders/smoke_fragment.glsl");
    Shader groundShader = Shader_New("shaders/ground_vert.glsl", "shaders/ground_frag.glsl");

    // Configure scene shader
    Shader_Use(&sceneShader);
    Shader_SetInt(&sceneShader, "texture_diffuse1", 0);

    // --- Ground plane VAO/VBO ---
    float groundVerts[] = {
      -BOUND, 0.0f, -BOUND,
      -BOUND, 0.0f,  BOUND,
       BOUND, 0.0f,  BOUND,
       BOUND, 0.0f, -BOUND
    };
    unsigned groundVAO, groundVBO;
    glGenVertexArrays(1, &groundVAO);
    glGenBuffers(1, &groundVBO);
    glBindVertexArray(groundVAO);
      glBindBuffer(GL_ARRAY_BUFFER, groundVBO);
      glBufferData(GL_ARRAY_BUFFER, sizeof(groundVerts), groundVerts, GL_STATIC_DRAW);
      glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, 0);
      glEnableVertexAttribArray(0);
    glBindVertexArray(0);

    // --- Smoke VAO/VBO ---
    unsigned smokeVAO, smokeVBO;
    glGenVertexArrays(1, &smokeVAO);
    glGenBuffers(1, &smokeVBO);
    glBindVertexArray(smokeVAO);
      glBindBuffer(GL_ARRAY_BUFFER, smokeVBO);
      glBufferData(GL_ARRAY_BUFFER, MAX_PARTICLES*4*sizeof(float), NULL, GL_STREAM_DRAW);
      glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 0, 0);
      glEnableVertexAttribArray(0);
    glBindVertexArray(0);

    // --- Ball model & texture ---
    Model ballModel;
    if (!Model_Load(&ballModel, "assets/ball_uv.obj")) return EXIT_FAILURE;
    unsigned ballTex = Texture_FromFile("assets/ball_diffuse.png");

    // --- Camera & fog init ---
    Camera_Init(&camera, (vec3){0,1,5}, (vec3){0,1,0}, CAMERA_YAW, CAMERA_PITCH);
    Fog fog; Fog_Init(&fog, 0.045f, 1.5f);

    // Field parameters
    const float gz      = -8.0f;  // goal line
    const float paDepth =  5.0f;  // penalty area depth
    const float paHalfW =  6.0f;  // penalty half-width
    const float spotZ   = gz + (11.0f/16.5f)*paDepth + 2.0f; // ball starts further back
    const float netZ    = gz - 0.5f;  // net slightly behind goal line

    // Ball initial state
    vec3 ballPos = {0, BALL_RADIUS, spotZ};
    vec3 ballVel = {0,0,0};
    bool  scored  = false;
    float resetTimer = 0.0f;

    // --- Boundary line VAO ---
    float boundary[] = {-paHalfW,0,gz, paHalfW,0,gz};
    unsigned bVAO, bVBO;
    glGenVertexArrays(1, &bVAO);
    glGenBuffers(1, &bVBO);
    glBindVertexArray(bVAO);
      glBindBuffer(GL_ARRAY_BUFFER, bVBO);
      glBufferData(GL_ARRAY_BUFFER, sizeof(boundary), boundary, GL_STATIC_DRAW);
      glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,0,0);
      glEnableVertexAttribArray(0);
    glBindVertexArray(0);

    // --- Penalty area lines VAO ---
    float paLines[] = {
      -paHalfW,0,gz,   -paHalfW,0,gz-paDepth,
       paHalfW,0,gz,    paHalfW,0,gz-paDepth,
      -paHalfW,0,gz-paDepth, paHalfW,0,gz-paDepth
    };
    unsigned paVAO, paVBO;
    glGenVertexArrays(1, &paVAO);
    glGenBuffers(1, &paVBO);
    glBindVertexArray(paVAO);
      glBindBuffer(GL_ARRAY_BUFFER, paVBO);
      glBufferData(GL_ARRAY_BUFFER, sizeof(paLines), paLines, GL_STATIC_DRAW);
      glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,0,0);
      glEnableVertexAttribArray(0);
    glBindVertexArray(0);

    // --- Front net VAO ---
    enum { NET_R=10, NET_C=20 };
    int netCount = (NET_R+1 + NET_C+1)*2;
    float *netLines = malloc(netCount*3*sizeof(float));
    int idx = 0;
    for (int i = 0; i <= NET_R; i++) {
      float y = i * (2.0f/NET_R);
      netLines[idx++] = -3; netLines[idx++] = y; netLines[idx++] = netZ;
      netLines[idx++] =  3; netLines[idx++] = y; netLines[idx++] = netZ;
    }
    for (int j = 0; j <= NET_C; j++) {
      float x = -3 + j * (6.0f/NET_C);
      netLines[idx++] = x; netLines[idx++] = 0; netLines[idx++] = netZ;
      netLines[idx++] = x; netLines[idx++] = 2; netLines[idx++] = netZ;
    }
    unsigned netVAO, netVBO;
    glGenVertexArrays(1, &netVAO);
    glGenBuffers(1, &netVBO);
    glBindVertexArray(netVAO);
      glBindBuffer(GL_ARRAY_BUFFER, netVBO);
      glBufferData(GL_ARRAY_BUFFER, idx*sizeof(float), netLines, GL_STATIC_DRAW);
      glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,0,0);
      glEnableVertexAttribArray(0);
    glBindVertexArray(0);
    free(netLines);

    // --- Goal frame VAO ---
    float goalLines[] = {
      -3,0,gz+0.1f,  -3,2,gz+0.1f,
       3,0,gz+0.1f,   3,2,gz+0.1f,
      -3,2,gz+0.1f,   3,2,gz+0.1f
    };
    unsigned goalVAO, goalVBO;
    glGenVertexArrays(1, &goalVAO);
    glGenBuffers(1, &goalVBO);
    glBindVertexArray(goalVAO);
      glBindBuffer(GL_ARRAY_BUFFER, goalVBO);
      glBufferData(GL_ARRAY_BUFFER, sizeof(goalLines), goalLines, GL_STATIC_DRAW);
      glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,0,0);
      glEnableVertexAttribArray(0);
    glBindVertexArray(0);

    // --- Penalty spot circle VAO ---
    enum { CIRC_SEG = 32 };
    float circleVerts[CIRC_SEG*3];
    for (int i = 0; i < CIRC_SEG; i++) {
      float ang = 2.0f * GLM_PI * ((float)i / CIRC_SEG);
      circleVerts[3*i+0] = 0.2f * cosf(ang);
      circleVerts[3*i+1] = 0.01f;
      circleVerts[3*i+2] = 0.2f * sinf(ang);
    }
    unsigned circVAO, circVBO;
    glGenVertexArrays(1, &circVAO);
    glGenBuffers(1, &circVBO);
    glBindVertexArray(circVAO);
      glBindBuffer(GL_ARRAY_BUFFER, circVBO);
      glBufferData(GL_ARRAY_BUFFER, sizeof(circleVerts), circleVerts, GL_STATIC_DRAW);
      glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,0,0);
      glEnableVertexAttribArray(0);
    glBindVertexArray(0);

    // --- Posts & crossbar VAO ---
    unsigned cubeVAO, cubeVBO;
    glGenVertexArrays(1, &cubeVAO);
    glGenBuffers(1, &cubeVBO);
    glBindVertexArray(cubeVAO);
      glBindBuffer(GL_ARRAY_BUFFER, cubeVBO);
      glBufferData(GL_ARRAY_BUFFER, sizeof(cubeMesh), cubeMesh, GL_STATIC_DRAW);
      glVertexAttribPointer(0,3,GL_FLOAT,GL_FALSE,3*sizeof(float),(void*)0);
      glEnableVertexAttribArray(0);
    glBindVertexArray(0);

    // --- Main loop ---
    while (!glfwWindowShouldClose(window)) {
      float now = (float)glfwGetTime();
      deltaTime = now - lastFrame;
      lastFrame = now;

      processInput(window);

      // --- Kick detection ---
      vec3 diff;
      glm_vec3_sub(ballPos, camera.Position, diff);
      if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS &&
          glm_vec3_norm(diff) < 2.0f)
      {
        vec3 d;
        glm_vec3_copy(camera.Front, d);
        d[1] = 0.2f;
        glm_vec3_normalize(d);
        glm_vec3_scale(d, KICK_FORCE, ballVel);
      }

      // --- Physics update ---
      ballVel[1] -= GRAVITY * deltaTime;
      vec3 dv; glm_vec3_scale(ballVel, deltaTime, dv);
      glm_vec3_add(ballPos, dv, ballPos);

      // ground collision
      if (ballPos[1] < BALL_RADIUS) {
        ballPos[1] = BALL_RADIUS;
        ballVel[1] *= -0.5f;
        ballVel[0] *= FRICTION;
        ballVel[2] *= FRICTION;
      }
      // field bounds
      ballPos[0] = fmaxf(-BOUND, fminf(BOUND, ballPos[0]));
      ballPos[2] = fmaxf(-BOUND, fminf(BOUND, ballPos[2]));

      // net collision
      if (ballPos[2] - BALL_RADIUS < netZ &&
          ballPos[0] > -3 && ballPos[0] < 3 &&
          ballPos[1] > 0 && ballPos[1] < 2)
      {
        ballPos[2] = netZ + BALL_RADIUS;
        ballVel[2] *= -0.5f;
      }

      updateSmoke(deltaTime);

      // --- Goal detection & reset ---
      if (!scored &&
          ballPos[2] - BALL_RADIUS < gz &&
          ballPos[0] > -3.0f && ballPos[0] < 3.0f &&
          ballPos[1] < 2.0f)
      {
        scored     = true;
        resetTimer = 2.0f;
        spawnSmoke(ballPos, 200);
        printf("GOAL!!! 🥳\n");
      }
      if (scored) {
        resetTimer -= deltaTime;
        if (resetTimer <= 0.0f) {
          // reset ball
          ballPos[0] = 0;  ballPos[1] = BALL_RADIUS;  ballPos[2] = spotZ;
          ballVel[0] = ballVel[1] = ballVel[2] = 0;
          // reset camera
          camera.Position[0] = 0;  camera.Position[1] = 1;  camera.Position[2] = 5;
          camera.Yaw   = -90.0f;  camera.Pitch = 0.0f;
          Camera_UpdateVectors(&camera);
          scored = false;
        }
      }

      // --- Compute matrices ---
      mat4 proj, view;
      glm_perspective(glm_rad(camera.Zoom),
                      (float)SCR_WIDTH/SCR_HEIGHT,
                      0.1f, 100.0f, proj);
      Camera_GetViewMatrix(&camera, view);

      // --- Render ground ---
      glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
      Shader_Use(&groundShader);
      mat4 I = GLM_MAT4_IDENTITY_INIT;
      Shader_SetMat4(&groundShader, "model",      I);
      Shader_SetMat4(&groundShader, "view",       view);
      Shader_SetMat4(&groundShader, "projection", proj);
      glBindVertexArray(groundVAO);
      glDrawArrays(GL_TRIANGLE_FAN, 0, 4);

      // --- Render lines & net & goal frame ---
      Shader_Use(&lineShader);
      Shader_SetMat4(&lineShader, "view",       view);
      Shader_SetMat4(&lineShader, "projection", proj);

      glBindVertexArray(bVAO);    glDrawArrays(GL_LINES, 0, 2);
      glBindVertexArray(paVAO);   glDrawArrays(GL_LINES, 0, 6);
      glBindVertexArray(netVAO);  glDrawArrays(GL_LINES, 0, netCount);
      glBindVertexArray(goalVAO); glDrawArrays(GL_LINES, 0, 6);

      // --- Render penalty spot ---
      Shader_Use(&sceneShader);
      mat4 M;
      glm_mat4_identity(M);
      glm_translate(M, (vec3){0.0f, 0.01f, spotZ});
      Shader_SetMat4(&sceneShader, "model", M);
      Shader_SetMat4(&sceneShader, "view",  view);
      Shader_SetMat4(&sceneShader, "projection", proj);
      glBindVertexArray(circVAO);
      glDrawArrays(GL_LINE_LOOP, 0, CIRC_SEG);

      // --- Render posts & crossbar ---
      // left post
      glm_mat4_identity(M);
      glm_translate(M, (vec3){-3,1,gz+0.1f});
      glm_scale(M,     (vec3){0.1f,2.0f,0.1f});
      Shader_SetMat4(&sceneShader, "model", M);
      glBindVertexArray(cubeVAO);
      glDrawArrays(GL_TRIANGLES, 0, 36);
      // right post
      glm_mat4_identity(M);
      glm_translate(M, (vec3){ 3,1,gz+0.1f});
      glm_scale(M,     (vec3){0.1f,2.0f,0.1f});
      Shader_SetMat4(&sceneShader, "model", M);
      glDrawArrays(GL_TRIANGLES, 0, 36);
      // crossbar
      glm_mat4_identity(M);
      glm_translate(M, (vec3){0,2,gz+0.1f});
      glm_scale(M,     (vec3){6.0f,0.1f,0.1f});
      Shader_SetMat4(&sceneShader, "model", M);
      glDrawArrays(GL_TRIANGLES, 0, 36);

      // --- Render ball ---
      Shader_SetBool(&sceneShader, "useTexture", true);
      glActiveTexture(GL_TEXTURE0);
      glBindTexture(GL_TEXTURE_2D, ballTex);
      glm_mat4_identity(M);
      glm_translate(M, ballPos);
      glm_scale(M,     (vec3){BALL_RADIUS,BALL_RADIUS,BALL_RADIUS});
      Shader_SetMat4(&sceneShader, "model", M);
      Fog_Apply(&fog, &sceneShader);
      Model_Draw(&ballModel);
      glBindTexture(GL_TEXTURE_2D, 0);

      // --- Render smoke ---
      float *buf = malloc(particleCount*4*sizeof(float));
      for (int i = 0; i < particleCount; i++) {
        buf[4*i+0] = particles[i].pos[0];
        buf[4*i+1] = particles[i].pos[1];
        buf[4*i+2] = particles[i].pos[2];
        buf[4*i+3] = particles[i].life;
      }
      glBindBuffer(GL_ARRAY_BUFFER, smokeVBO);
      glBufferSubData(GL_ARRAY_BUFFER, 0,
                      particleCount*4*sizeof(float), buf);
      free(buf);
      Shader_Use(&smokeShader);
      Shader_SetMat4(&smokeShader, "projection", proj);
      Shader_SetMat4(&smokeShader, "view",       view);
      glBindVertexArray(smokeVAO);
      glDrawArrays(GL_POINTS, 0, particleCount);

      // swap & poll
      glfwSwapBuffers(window);
      glfwPollEvents();
    }

    // --- Cleanup ---
    Model_Cleanup(&ballModel);
    Shader_Delete(&sceneShader);
    Shader_Delete(&lineShader);
    Shader_Delete(&smokeShader);
    Shader_Delete(&groundShader);

    glDeleteVertexArrays(1,&groundVAO);
    glDeleteBuffers(1,&groundVBO);
    glDeleteVertexArrays(1,&smokeVAO);
    glDeleteBuffers(1,&smokeVBO);
    glDeleteVertexArrays(1,&bVAO);
    glDeleteBuffers(1,&bVBO);
    glDeleteVertexArrays(1,&paVAO);
    glDeleteBuffers(1,&paVBO);
    glDeleteVertexArrays(1,&netVAO);
    glDeleteBuffers(1,&netVBO);
    glDeleteVertexArrays(1,&goalVAO);
    glDeleteBuffers(1,&goalVBO);
    glDeleteVertexArrays(1,&circVAO);
    glDeleteBuffers(1,&circVBO);
    glDeleteVertexArrays(1,&cubeVAO);
    glDeleteBuffers(1,&cubeVBO);

    glfwTerminate();
    return EXIT_SUCCESS;
}

// processInput: WASD moves camera, arrows rotate it
void processInput(GLFWwindow* w) {
    if (glfwGetKey(w, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(w, true);

    Camera_ProcessKeyboard(&camera, CAMERA_MV_FORWARD,
        deltaTime * (glfwGetKey(w, GLFW_KEY_W)==GLFW_PRESS ? CAM_SPEED : 1.0f));
    Camera_ProcessKeyboard(&camera, CAMERA_MV_BACKWARD,
        deltaTime * (glfwGetKey(w, GLFW_KEY_S)==GLFW_PRESS ? CAM_SPEED : 1.0f));
    Camera_ProcessKeyboard(&camera, CAMERA_MV_LEFT,
        deltaTime * (glfwGetKey(w, GLFW_KEY_A)==GLFW_PRESS ? CAM_SPEED : 1.0f));
    Camera_ProcessKeyboard(&camera, CAMERA_MV_RIGHT,
        deltaTime * (glfwGetKey(w, GLFW_KEY_D)==GLFW_PRESS ? CAM_SPEED : 1.0f));

    float xoff=0, yoff=0, spd=50.0f;
    if (glfwGetKey(w, GLFW_KEY_LEFT )==GLFW_PRESS) xoff=-spd*deltaTime;
    if (glfwGetKey(w, GLFW_KEY_RIGHT)==GLFW_PRESS) xoff= spd*deltaTime;
    if (glfwGetKey(w, GLFW_KEY_UP   )==GLFW_PRESS) yoff= spd*deltaTime;
    if (glfwGetKey(w, GLFW_KEY_DOWN )==GLFW_PRESS) yoff=-spd*deltaTime;
    if (xoff!=0 || yoff!=0)
        Camera_ProcessMouseMovement(&camera, xoff, yoff, true);
}

void framebuffer_size_callback(GLFWwindow* w,int ww,int hh){
    (void)w; glViewport(0,0,ww,hh);
}
void mouse_callback(GLFWwindow* w,double xpos,double ypos){
    if (firstMouse) {
        lastX = xpos; lastY = ypos; firstMouse = false;
    }
    float xoff = (float)xpos - lastX;
    float yoff = lastY - (float)ypos;
    lastX = xpos; lastY = ypos;
    Camera_ProcessMouseMovement(&camera, xoff, yoff, true);
}
void scroll_callback(GLFWwindow* w,double xoffset,double yoffset){
    (void)xoffset;
    Camera_ProcessMouseScroll(&camera, (float)yoffset);
}
