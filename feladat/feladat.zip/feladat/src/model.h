// src/model.h

#ifndef MODEL_H
#define MODEL_H

#include <stdbool.h>    // ← ide került
#include <GL/glew.h>

// Simple model holding one mesh (VAO/EBO) loaded via Assimp C API
typedef struct {
    GLuint VAO;
    GLuint VBO;
    GLuint EBO;
    GLuint indexCount;
} Model;

// Load the first mesh from 'path' into GPU buffers
// Returns false on failure
bool Model_Load(Model *model, const char *path);

// Draws the mesh (assumes a shader is already in use)
void Model_Draw(const Model *model);

// Releases GPU resources
void Model_Cleanup(Model *model);

#endif // MODEL_H
