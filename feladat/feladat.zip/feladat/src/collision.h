// src/collision.h

#ifndef COLLISION_H
#define COLLISION_H

#include <stdbool.h>
#include <cglm/cglm.h>

// Axis-aligned bounding box
typedef struct {
    vec3 min;  // box->min[0]=x, [1]=y, [2]=z
    vec3 max;  // box->max[0]=x, [1]=y, [2]=z
} AABB;

// Ellenőrzi, hogy a pont (point) benne van-e a box-ban
bool AABB_CheckCollision(const AABB *box, const vec3 point);

#endif // COLLISION_H
