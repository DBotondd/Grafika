// src/shader.h
#ifndef SHADER_H
#define SHADER_H

#include <stdbool.h>
#include <GL/glew.h>
#include <cglm/cglm.h>

// A simple wrapper around an OpenGL shader program
typedef struct {
    unsigned int ID;
} Shader;

// Compile & link a vertex+fragment shader from disk
Shader Shader_New(const char* vertexPath, const char* fragmentPath);

// Activate/use the shader
void Shader_Use(Shader* shader);

// Uniform setters
void Shader_SetVec3(Shader *shader, const char *name, vec3 value);
void Shader_SetBool (Shader* shader, const char* name, bool    value);
void Shader_SetInt  (Shader* shader, const char* name, int     value);
void Shader_SetFloat(Shader* shader, const char* name, float   value);
void Shader_SetMat4 (Shader* shader, const char* name, const mat4 value);

// Cleanup
void Shader_Delete(Shader* shader);

#endif // SHADER_H
