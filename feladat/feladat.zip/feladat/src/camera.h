// src/camera.h

#pragma once

#include <stdbool.h>
#include <cglm/cglm.h>

typedef enum {
    CAMERA_MV_FORWARD,
    CAMERA_MV_BACKWARD,
    CAMERA_MV_LEFT,
    CAMERA_MV_RIGHT
} Camera_Movement;

#define CAMERA_YAW         -90.0f
#define CAMERA_PITCH        0.0f
#define CAMERA_SPEED        2.5f
#define CAMERA_SENSITIVITY  0.1f
#define CAMERA_ZOOM         45.0f

typedef struct {
    vec3 Position;
    vec3 Front;
    vec3 Up;
    vec3 Right;
    vec3 WorldUp;
    float Yaw;
    float Pitch;
    float MovementSpeed;
    float MouseSensitivity;
    float Zoom;
} Camera;

// Initialize camera; must call before use
void Camera_Init(Camera *cam,
                 vec3 position,
                 vec3 up,
                 float yaw,
                 float pitch);

// Fill `view` matrix with lookAt(Position, Position+Front, Up)
void Camera_GetViewMatrix(const Camera *cam, mat4 view);

// Process WASD input
void Camera_ProcessKeyboard(Camera *cam,
                            Camera_Movement direction,
                            float deltaTime);

// Process mouse movement (xoffset, yoffset in degrees by default)
void Camera_ProcessMouseMovement(Camera *cam,
                                 float xoffset,
                                 float yoffset,
                                 bool constrainPitch);

// Process scroll to zoom
void Camera_ProcessMouseScroll(Camera *cam,
                               float yoffset);

// Update cam->Front, Right, Up from current Yaw/Pitch
void Camera_UpdateVectors(Camera *cam);
